"""
GCP Guardrail - Content Safety System
======================================
A unified guardrail combining GCP Natural Language API and Model Armor.

Usage:
    from gcp_guardrail import GuardrailRunner
    
    runner = GuardrailRunner(
        config_path="config.json",
        key_path="path/to/service_account.json"
    )
    result = runner.run("Your text here")
"""

from .runner import GuardrailRunner
from .enums import GuardrailType, CheckType, ModerationCategory, EntityType, GuardrailResult

__version__ = "1.0.0"
__all__ = [
    "GuardrailRunner",
    "GuardrailType",
    "CheckType",
    "ModerationCategory",
    "EntityType",
    "GuardrailResult",
]

