"""Unified guardrail combining NLP API and Model Armor."""

import os
from typing import Dict, Any, Optional, List, Union

from google.api_core import exceptions as google_exceptions

from .nlp_client import NLPClient
from .model_armor_client import ModelArmorClient
from .enums import (
    GuardrailType, CheckType, EntityType, ModerationCategory,
    GuardrailResult, parse_check_type
)


class GeminiGuardrail:
    """Unified guardrail combining NLP API and Model Armor."""

    def __init__(self, key_path: str, project_id: str, location_id: str, template_id: str):
        self._key_path = key_path
        self._project_id = project_id
        self._location_id = location_id
        self._template_id = template_id
        self._nlp_client: Optional[NLPClient] = None
        self._armor_client: Optional[ModelArmorClient] = None

    def _get_nlp_client(self) -> NLPClient:
        if self._nlp_client is None:
            self._nlp_client = NLPClient(self._key_path)
        return self._nlp_client

    def _get_armor_client(self) -> ModelArmorClient:
        if self._armor_client is None:
            self._armor_client = ModelArmorClient(self._key_path, self._project_id, self._location_id, self._template_id)
        return self._armor_client

    def _handle_error(self, e: Exception, guardrail_type: str) -> GuardrailResult:
        error_msg = str(e)
        if isinstance(e, google_exceptions.InvalidArgument):
            error_msg = f"Invalid input: {getattr(e, 'message', str(e))}"
        elif isinstance(e, google_exceptions.PermissionDenied):
            error_msg = "Permission denied. Check API credentials."
        elif isinstance(e, google_exceptions.NotFound):
            error_msg = "Resource not found. Check configuration."
        elif isinstance(e, google_exceptions.ResourceExhausted):
            error_msg = "API quota exceeded."
        elif isinstance(e, google_exceptions.ServiceUnavailable):
            error_msg = "Service temporarily unavailable."
        return GuardrailResult(guardrail_type=guardrail_type, error=error_msg)

    def check_sentiment(self, text: str) -> GuardrailResult:
        try:
            if not text or not text.strip():
                return GuardrailResult(guardrail_type=GuardrailType.NLP_SENTIMENT.value, error="Text cannot be empty")
            result = self._get_nlp_client().analyze_sentiment(text)
            return GuardrailResult(guardrail_type=GuardrailType.NLP_SENTIMENT.value, results=result)
        except Exception as e:
            return self._handle_error(e, GuardrailType.NLP_SENTIMENT.value)

    def check_entities(self, text: str, blocked_types: Optional[List[Union[str, EntityType]]] = None) -> GuardrailResult:
        try:
            if not text or not text.strip():
                return GuardrailResult(guardrail_type=GuardrailType.NLP_ENTITIES.value, error="Text cannot be empty")
            result = self._get_nlp_client().analyze_entities(text, blocked_types)
            return GuardrailResult(guardrail_type=GuardrailType.NLP_ENTITIES.value,
                                   results={"entities": result["entities"]}, blocked_items=result["blocked"])
        except Exception as e:
            return self._handle_error(e, GuardrailType.NLP_ENTITIES.value)

    def check_classification(self, text: str, blocked_categories: Optional[List[str]] = None, threshold: float = 0.5) -> GuardrailResult:
        try:
            if not text or not text.strip():
                return GuardrailResult(guardrail_type=GuardrailType.NLP_CLASSIFY.value, error="Text cannot be empty")
            result = self._get_nlp_client().classify_text(text, blocked_categories, threshold)
            if "error" in result:
                return GuardrailResult(guardrail_type=GuardrailType.NLP_CLASSIFY.value, error=result["error"])
            return GuardrailResult(guardrail_type=GuardrailType.NLP_CLASSIFY.value,
                                   results={"categories": result["categories"]}, blocked_items=result["blocked"])
        except Exception as e:
            return self._handle_error(e, GuardrailType.NLP_CLASSIFY.value)

    def check_moderation(self, text: str, blocked_categories: Optional[List[Union[str, ModerationCategory]]] = None,
                         thresholds: Optional[Dict[Union[str, ModerationCategory], float]] = None) -> GuardrailResult:
        try:
            if not text or not text.strip():
                return GuardrailResult(guardrail_type=GuardrailType.NLP_MODERATE.value, error="Text cannot be empty")
            result = self._get_nlp_client().moderate_text(text, blocked_categories, thresholds)
            return GuardrailResult(guardrail_type=GuardrailType.NLP_MODERATE.value,
                                   results={"moderation": result["moderation"]}, blocked_items=result["blocked"])
        except Exception as e:
            return self._handle_error(e, GuardrailType.NLP_MODERATE.value)

    def check_model_armor(self, text: str, check_type: Union[str, CheckType] = CheckType.USER_PROMPT) -> GuardrailResult:
        try:
            if not text or not text.strip():
                return GuardrailResult(guardrail_type=GuardrailType.MODEL_ARMOR.value, error="Text cannot be empty")
            parsed_check_type = parse_check_type(check_type)
            client = self._get_armor_client()
            if parsed_check_type == CheckType.USER_PROMPT:
                result = client.sanitize_user_prompt(text)
            else:
                result = client.sanitize_model_response(text)
            return GuardrailResult(guardrail_type=GuardrailType.MODEL_ARMOR.value,
                                   results={"filter_results": result["filter_results"], "overall_match_state": result["overall_match_state"]},
                                   blocked_items=result["blocked_filters"])
        except Exception as e:
            return self._handle_error(e, GuardrailType.MODEL_ARMOR.value)

