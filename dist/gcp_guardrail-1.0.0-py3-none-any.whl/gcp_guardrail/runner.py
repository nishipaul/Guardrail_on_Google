"""Main GuardrailRunner interface for content safety checks."""

import os
import json
import time
import re
from datetime import datetime
from typing import Dict, Any, Optional, List, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed

from .guardrail import GeminiGuardrail
from .enums import GuardrailType, CheckType


NLP_API_ENTITY_TYPES = {
    "UNKNOWN", "PERSON", "LOCATION", "ORGANIZATION", "EVENT", "WORK_OF_ART",
    "CONSUMER_GOOD", "OTHER", "PHONE_NUMBER", "ADDRESS", "EMAIL", "URL",
    "DATE", "NUMBER", "PRICE", "IBAN", "FLIGHT_NUMBER", "ID_NUMBER"
}

PII_PATTERNS = {
    "PHONE_NUMBER": [r'\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b', r'\b\(\d{3}\)\s*\d{3}[-.\s]?\d{4}\b',
                     r'\b\+\d{1,3}[-.\s]?\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b', r'\b\d{10}\b'],
    "EMAIL": [r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'],
    "SSN": [r'\b\d{3}[-.\s]?\d{2}[-.\s]?\d{4}\b'],
    "CREDIT_CARD": [r'\b\d{4}[-.\s]?\d{4}[-.\s]?\d{4}[-.\s]?\d{4}\b'],
}

FUNCTION_MAP = {
    "sentiment": GuardrailType.NLP_SENTIMENT, "analyze_sentiment": GuardrailType.NLP_SENTIMENT,
    "entities": GuardrailType.NLP_ENTITIES, "analyze_entities": GuardrailType.NLP_ENTITIES,
    "classify": GuardrailType.NLP_CLASSIFY, "classify_text": GuardrailType.NLP_CLASSIFY,
    "moderate": GuardrailType.NLP_MODERATE, "moderate_text": GuardrailType.NLP_MODERATE,
    "model_armor": GuardrailType.MODEL_ARMOR, "armor": GuardrailType.MODEL_ARMOR
}

DISPLAY_NAMES = {
    GuardrailType.NLP_SENTIMENT: "analyze_sentiment", GuardrailType.NLP_ENTITIES: "analyze_entities",
    GuardrailType.NLP_CLASSIFY: "classify_text", GuardrailType.NLP_MODERATE: "moderate_text",
    GuardrailType.MODEL_ARMOR: "model_armor"
}


class GuardrailRunner:
    """End-user interface for running guardrail checks."""

    def __init__(self, config_path: str, key_path: str, project_id: str = "ai-experiments-345006",
                 location: str = "us-central1", template_id: str = "litellm-gcp-guard",
                 user_name: str = "simpplr_user", enable_logging: bool = True, log_dir: Optional[str] = None):
        """
        Initialize the GuardrailRunner.

        Args:
            config_path: Path to config.json file
            key_path: Path to GCP service account JSON file
            project_id: GCP project ID
            location: GCP region
            template_id: Model Armor template ID
            user_name: Name to identify the user in log files
            enable_logging: Whether to enable logging
            log_dir: Directory for logs (default: ./gcp_guardrail_log)
        """
        self._config_path = config_path
        self._key_path = key_path
        self._project_id = project_id
        self._location = location
        self._template_id = template_id
        self._user_name = user_name
        self._enable_logging = enable_logging
        self._log_dir = log_dir or os.path.join(os.getcwd(), "gcp_guardrail_log")
        self._config: Dict[str, Any] = {}
        self._guardrail: Optional[GeminiGuardrail] = None

        self._load_config()
        self._initialize_guardrail()
        self._setup_logging()

    def _load_config(self) -> None:
        if not os.path.exists(self._config_path):
            raise FileNotFoundError(f"Config file not found: {self._config_path}")
        with open(self._config_path, 'r') as f:
            self._config = json.load(f)

    def _initialize_guardrail(self) -> None:
        self._guardrail = GeminiGuardrail(
            key_path=self._key_path, project_id=self._project_id,
            location_id=self._location, template_id=self._template_id
        )

    def _setup_logging(self) -> None:
        if not self._enable_logging:
            self._log_file_path = None
            return
        os.makedirs(self._log_dir, exist_ok=True)
        today = datetime.now().strftime("%Y-%m-%d")
        self._log_file_path = os.path.join(self._log_dir, f"{self._user_name}_{today}.json")

    def _log_query(self, input_text: str, output_result: Dict[str, Any]) -> None:
        if not self._enable_logging or not self._log_file_path:
            return
        log_entry = {"query_timestamp": datetime.now().isoformat(), "user_name": self._user_name,
                     "input_text": input_text, "output_result": output_result}
        logs = []
        if os.path.exists(self._log_file_path):
            try:
                with open(self._log_file_path, 'r') as f:
                    logs = json.load(f)
            except (json.JSONDecodeError, IOError):
                logs = []
        logs.append(log_entry)
        with open(self._log_file_path, 'w') as f:
            json.dump(logs, indent=2, fp=f, ensure_ascii=False)

    def _get_functions_for_phase(self, phase: str) -> Tuple[List[GuardrailType], str]:
        phase_config = self._config.get(phase, {})
        function_names = phase_config.get("functions", [])
        execution_type = phase_config.get("execution_type", "sequential").lower()
        if execution_type not in ("sequential", "parallel"):
            execution_type = "sequential"
        functions = []
        for name in function_names:
            guardrail_type = FUNCTION_MAP.get(name.lower())
            if guardrail_type and guardrail_type not in functions:
                functions.append(guardrail_type)
        return functions, execution_type

    def _check_sentiment_blocking(self, result: Dict[str, Any], phase_config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if phase_config.get("analyze_sentiment_block_negative", True) is False:
            return None
        score = result.get("score", 0)
        magnitude = result.get("magnitude", 0)
        score_threshold = phase_config.get("analyze_sentiment_score_threshold", -0.50)
        magnitude_threshold = phase_config.get("analyze_sentiment_magnitude_threshold")
        blocked, reason = False, []
        if score_threshold is not None and score <= score_threshold:
            blocked, reason = True, reason + [f"score ({score}) <= threshold ({score_threshold})"]
        if magnitude_threshold is not None and magnitude >= magnitude_threshold:
            blocked, reason = True, reason + [f"magnitude ({magnitude}) >= threshold ({magnitude_threshold})"]
        if blocked:
            return {"category": "negative_sentiment", "score": score, "magnitude": magnitude, "reason": ", ".join(reason)}
        return None

    def _check_entity_blocking(self, entities: List[Dict], phase_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        blocked_types = phase_config.get("analyze_entities_blocked_types")
        if not blocked_types:
            return []
        default_threshold = phase_config.get("analyze_entities_salience_threshold", 0.0)
        thresholds = {k.upper(): v for k, v in phase_config.get("analyze_entities_salience_thresholds", {}).items()}
        blocked_upper = [t.upper() for t in blocked_types]
        blocked = []
        for entity in entities:
            etype = entity.get("type", "").upper()
            if etype in blocked_upper:
                threshold = thresholds.get(etype, default_threshold)
                if entity.get("salience", 0) >= threshold:
                    blocked.append({"category": "entity_blocked", "entity_name": entity.get("name"),
                                   "entity_type": etype, "salience": entity.get("salience"), "threshold": threshold, "detection_method": "nlp_api"})
        return blocked

    def _check_pii_with_regex(self, text: str, phase_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        blocked_types = phase_config.get("analyze_entities_blocked_types")
        if not blocked_types:
            return []
        blocked_upper = [t.upper() for t in blocked_types]
        thresholds = {k.upper(): v for k, v in phase_config.get("analyze_entities_salience_thresholds", {}).items()}
        default_threshold = phase_config.get("analyze_entities_salience_threshold", 0.0)
        blocked, found = [], set()
        for pii_type, patterns in PII_PATTERNS.items():
            if pii_type not in blocked_upper:
                continue
            for pattern in patterns:
                for match in re.findall(pattern, text, re.IGNORECASE):
                    if match not in found:
                        found.add(match)
                        blocked.append({"category": "pii_detected", "entity_name": match, "entity_type": pii_type,
                                       "salience": 1.0, "threshold": thresholds.get(pii_type, default_threshold), "detection_method": "regex"})
        return blocked

    def _check_classification_blocking(self, categories: List[Dict], phase_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        blocked_cats = phase_config.get("classify_text_blocked_categories")
        if not blocked_cats:
            return []
        threshold = phase_config.get("classify_text_threshold", 0.5)
        blocked_lower = [c.lower() for c in blocked_cats]
        blocked = []
        for cat in categories:
            for pattern in blocked_lower:
                if pattern in cat.get("category", "").lower() and cat.get("confidence", 0) >= threshold:
                    blocked.append({"category": cat["category"], "confidence": cat["confidence"], "matched_pattern": pattern, "threshold": threshold})
                    break
        return blocked

    def _check_moderation_blocking(self, moderation: List[Dict], phase_config: Dict[str, Any]) -> List[Dict[str, Any]]:
        blocked_cats = phase_config.get("moderate_text_blocked_categories")
        if blocked_cats is None:
            blocked_cats = [m.get("category") for m in moderation]
        thresholds = {k.lower(): v for k, v in phase_config.get("moderate_text_thresholds", {}).items()}
        blocked = []
        for mod in moderation:
            cat = mod.get("category", "")
            if cat in blocked_cats or cat.lower() in [c.lower() for c in blocked_cats]:
                threshold = thresholds.get(cat.lower(), 0.5)
                if mod.get("confidence", 0) >= threshold:
                    blocked.append({"category": cat, "confidence": mod["confidence"], "severity": mod.get("severity"), "threshold": threshold})
        return blocked

    def _run_function(self, text: str, guardrail_type: GuardrailType, phase_config: Dict[str, Any], check_type: CheckType) -> Dict[str, Any]:
        start = time.perf_counter()
        try:
            if guardrail_type == GuardrailType.NLP_SENTIMENT:
                result = self._guardrail.check_sentiment(text)
                output = {"results": result.results, "time_taken_seconds": round(time.perf_counter() - start, 4)}
                blocked = self._check_sentiment_blocking(result.results, phase_config)
                if blocked:
                    output["blocked_items"] = [blocked]
                if result.error:
                    output["error"] = result.error
                return output
            elif guardrail_type == GuardrailType.NLP_ENTITIES:
                blocked_types = [t for t in phase_config.get("analyze_entities_blocked_types", []) if t.upper() in NLP_API_ENTITY_TYPES]
                if blocked_types:
                    result = self._guardrail.check_entities(text, blocked_types)
                    entities = [e for e in result.results.get("entities", []) if e.get("type", "").upper() not in ("OTHER", "UNKNOWN")]
                    error = result.error
                else:
                    entities, error = [], None
                output = {"results": {"entities": entities}, "time_taken_seconds": round(time.perf_counter() - start, 4)}
                blocked = self._check_entity_blocking(entities, phase_config) + [r for r in self._check_pii_with_regex(text, phase_config) if r["entity_name"] not in {b["entity_name"] for b in self._check_entity_blocking(entities, phase_config)}]
                if blocked:
                    output["blocked_items"] = blocked
                if error:
                    output["error"] = error
                return output
            elif guardrail_type == GuardrailType.NLP_CLASSIFY:
                result = self._guardrail.check_classification(text, phase_config.get("classify_text_blocked_categories"), phase_config.get("classify_text_threshold", 0.5))
                output = {"results": result.results, "time_taken_seconds": round(time.perf_counter() - start, 4)}
                blocked = self._check_classification_blocking(result.results.get("categories", []), phase_config)
                if blocked:
                    output["blocked_items"] = blocked
                if result.error:
                    output["error"] = result.error
                return output
            elif guardrail_type == GuardrailType.NLP_MODERATE:
                result = self._guardrail.check_moderation(text, phase_config.get("moderate_text_blocked_categories"), phase_config.get("moderate_text_thresholds"))
                output = {"results": result.results, "time_taken_seconds": round(time.perf_counter() - start, 4)}
                blocked = self._check_moderation_blocking(result.results.get("moderation", []), phase_config)
                if blocked:
                    output["blocked_items"] = blocked
                if result.error:
                    output["error"] = result.error
                return output
            elif guardrail_type == GuardrailType.MODEL_ARMOR:
                result = self._guardrail.check_model_armor(text, check_type)
                output = {"results": result.results, "time_taken_seconds": round(time.perf_counter() - start, 4)}
                if result.blocked_items:
                    output["blocked_items"] = result.blocked_items
                if result.error:
                    output["error"] = result.error
                return output
            return {"error": "Unknown function", "time_taken_seconds": round(time.perf_counter() - start, 4)}
        except Exception as e:
            return {"error": str(e), "time_taken_seconds": round(time.perf_counter() - start, 4)}

    def _run_functions_parallel(self, text: str, functions: List[GuardrailType], phase_config: Dict[str, Any], check_type: CheckType) -> Dict[str, Any]:
        results = {}
        with ThreadPoolExecutor(max_workers=len(functions)) as executor:
            futures = {executor.submit(lambda gt=gt: (DISPLAY_NAMES.get(gt), self._run_function(text, gt, phase_config, check_type))): gt for gt in functions}
            for future in as_completed(futures):
                try:
                    name, result = future.result()
                    results[name] = result
                except Exception as e:
                    gt = futures[future]
                    results[DISPLAY_NAMES.get(gt)] = {"error": str(e), "time_taken_seconds": 0.0}
        return results

    def _run_functions_sequential(self, text: str, functions: List[GuardrailType], phase_config: Dict[str, Any], check_type: CheckType) -> Dict[str, Any]:
        return {DISPLAY_NAMES.get(gt): self._run_function(text, gt, phase_config, check_type) for gt in functions}

    def _build_summary(self, results: Dict[str, Any]) -> Dict[str, Any]:
        overall_passed, summaries = True, {}
        for phase in ["input", "output"]:
            if phase not in results:
                continue
            phase_results = results[phase]
            passed, failures = True, []
            for fname, fresult in phase_results.items():
                if fname in ("time_taken_seconds", "execution_type") or not isinstance(fresult, dict):
                    continue
                for item in fresult.get("blocked_items", []):
                    passed, overall_passed = False, False
                    failures.append({"function": fname, "category": item.get("category") or item.get("filter") or item.get("entity_type"),
                                    "confidence": item.get("confidence") or item.get("salience"), "severity": item.get("severity"), "reason": item.get("reason")})
                if fresult.get("error"):
                    passed, overall_passed = False, False
                    failures.append({"function": fname, "error": fresult["error"]})
            summaries[phase] = {"passed": passed, **({"failures": failures} if not passed else {})}
        return {"passed": overall_passed, **summaries}

    def run(self, text: str, generated_text: Optional[str] = None) -> Dict[str, Any]:
        """Run guardrail checks on text based on config."""
        if not text or not text.strip():
            result = {"error": "Input text cannot be empty", "summary": {"passed": False, "input": {"passed": False, "failures": [{"error": "Input text cannot be empty"}]}}}
            self._log_query(text, result)
            return result
        results, start = {}, time.perf_counter()
        if "input" in self._config:
            functions, exec_type = self._get_functions_for_phase("input")
            if functions:
                phase_start = time.perf_counter()
                phase_results = self._run_functions_parallel(text, functions, self._config["input"], CheckType.USER_PROMPT) if exec_type == "parallel" else self._run_functions_sequential(text, functions, self._config["input"], CheckType.USER_PROMPT)
                phase_results["time_taken_seconds"] = round(time.perf_counter() - phase_start, 4)
                phase_results["execution_type"] = exec_type
                results["input"] = phase_results
        if "output" in self._config:
            if not generated_text or not generated_text.strip():
                results["output"] = {"skipped": True, "message": "Output phase skipped: No generated_text provided.", "time_taken_seconds": 0.0}
            else:
                functions, exec_type = self._get_functions_for_phase("output")
                if functions:
                    phase_start = time.perf_counter()
                    phase_results = self._run_functions_parallel(generated_text, functions, self._config["output"], CheckType.MODEL_RESPONSE) if exec_type == "parallel" else self._run_functions_sequential(generated_text, functions, self._config["output"], CheckType.MODEL_RESPONSE)
                    phase_results["time_taken_seconds"] = round(time.perf_counter() - phase_start, 4)
                    phase_results["execution_type"] = exec_type
                    results["output"] = phase_results
        results["total_time_seconds"] = round(time.perf_counter() - start, 4)
        results["summary"] = self._build_summary(results)
        results["text"] = {"input_text": text, "generated_text": generated_text}
        self._log_query(text, results)
        return results

    def run_input(self, text: str) -> Dict[str, Any]:
        """Run only input phase checks."""
        orig = self._config.copy()
        self._config = {"input": self._config.get("input", {})}
        result = self.run(text)
        self._config = orig
        return result

    def run_output(self, generated_text: str) -> Dict[str, Any]:
        """Run only output phase checks."""
        if not generated_text or not generated_text.strip():
            return {"error": "Generated text cannot be empty", "summary": {"passed": False, "output": {"passed": False, "failures": [{"error": "Generated text cannot be empty"}]}}}
        orig = self._config.copy()
        self._config = {"output": self._config.get("output", {})}
        result = self.run("_output_only_", generated_text=generated_text)
        self._config = orig
        if "input" in result:
            del result["input"]
        return result

    def reload_config(self) -> None:
        """Reload configuration from file."""
        self._load_config()

    def get_log_file_path(self) -> Optional[str]:
        """Get the current log file path."""
        return self._log_file_path if self._enable_logging else None

    def get_logs(self) -> List[Dict[str, Any]]:
        """Read and return all logs from current log file."""
        if not self._enable_logging or not self._log_file_path or not os.path.exists(self._log_file_path):
            return []
        try:
            with open(self._log_file_path, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return []

